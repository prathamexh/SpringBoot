package com.activitytracker.demo.controller;

import java.net.http.HttpResponse;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PutMapping;
// import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.net.http.HttpResponse;
import com.activitytracker.demo.bean.Tasks;
import com.activitytracker.demo.bean.Users;
import com.activitytracker.demo.service.TaskService;
import com.activitytracker.demo.service.UserService;


// import org.springframework.web.bind.annotation.PathVariable;

//import com.activitytracker.demo.bean.Tasks;
//import com.activitytracker.demo.service.TaskService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private TaskService taskService;
    

    // adds new user
    @PostMapping("/signup")
    public ResponseEntity<?> signUp(@RequestBody Users usr){
        try {
            Tasks t = new Tasks();
            userService.addEmployee(usr);
            t.setTitle("Welcome to Activity Tracker");
            t.setDescription("How is your day, " + userService.getUid(usr).getName() + "?");
            t.setStatus("created");
            t.setUid(userService.getUid(usr).getId());
            taskService.addTask(t);
            return ResponseEntity.ok().body("User registered successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("User already exists");
        }
    }
    
    
    // authenticates user and sends all the tasks for the respective user
    // if creds dont match it will return null

    @PutMapping("/authenticate")
    public List<Tasks> auth(@RequestBody Users usr){
        List<Tasks> u = userService.getAll(usr);
        return u;
    }
}
