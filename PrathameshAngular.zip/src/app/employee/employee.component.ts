import {Component} from '@angular/core';

export interface PeriodicElement {
  
  id: number;
  name: string;
  email: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {id: 1, name: 'Deez', email: 'Deez@gmail.com'},
  {id: 2, name: 'Joe',  email: 'Joe@gmail.com'},
  {id:3, name: 'Kenya', email: 'Kenya@gmail.com'},
];

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {
  displayedColumns: string[] = ['id', 'name', 'email'];
  dataSource = ELEMENT_DATA;
}
