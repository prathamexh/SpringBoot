global using RESTAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace RESTAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentApiController : ControllerBase
    {
        private DataContext dataContext;

        public StudentApiController(DataContext context)
        {
            dataContext = context;
        }
        private static List<Student> students = new List<Student> {
            
            // new Student { Id = 1, Name = "Prathamesh", Section = "A", Email="Prathamesh@gmail.com"},
            // new Student { Id = 2, Name = "Locus", Section = "B", Email="Locus@gmail.com"}
        };

        [HttpGet("Get")]
        public ActionResult<IEnumerable<Student>> Get()
        {
            return dataContext.students.ToList();
            // return Ok(students);
        }
        [HttpGet("id")]
        public ActionResult<Student> GetSingle(int id)
        {
            return Ok(students.FirstOrDefault(c => c.Id == id));
        }

        [HttpPost]

        public ActionResult<List<Student>> AddStudent(Student newStudent)
        {
            dataContext.students.Add(newStudent);
            dataContext.SaveChanges();
            return Ok(students);
        }

        [HttpPut]
        public ActionResult<List<Student>> UpdateStudent(Student UpdateStudent)
        {
            Student student=dataContext.students.FirstOrDefault(c=>c.Id==UpdateStudent.Id);
            student.Name=UpdateStudent.Name;
            student.Section=UpdateStudent.Section;
            student.Email=UpdateStudent.Email;
            dataContext.SaveChanges();
            return Ok(student);
        }

        [HttpDelete("del/id")]
        public ActionResult<List<Student>> DeleteStudent (int Id)
        {
            Student student=dataContext.students.FirstOrDefault(c=>c.Id==Id);
            dataContext.students.Remove(student);
            dataContext.SaveChanges();
            return Ok(students);
        }
    }
}