package com.restapi.demo.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.restapi.demo.bean.Employee;
import com.restapi.demo.service.EmployeeService;
// import com.restapi.demo.repository.EmployeeRepository;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
public class EmployeeController {
  
    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/listEmployee")
    public  List<Employee> listAllEmployees(){    
            List<Employee> listofEmployees = employeeService.getAllEmployees();
            return listofEmployees;
    }

    @GetMapping("/listEmployee/{id}")
    public Employee getEmp(@PathVariable String id){
        System.out.print("im inside pathvariable");
        Employee gett =  employeeService.getEmp(Long.parseLong(id));
        return gett;
    }

    @PostMapping("/addEmployee")
    public Employee registerEmployee(@RequestBody Employee emp){
        System.out.println("new employee request data="+emp.getName()+" "+emp.getCity()+""+emp.getSalary());
        Employee newEmp = employeeService.addNewEmployee(emp);
        return newEmp;
    }
    
    @PutMapping(value="/emp/{id}")
    public Employee putEmployee(@PathVariable String id, @RequestBody Employee emp) {
        Employee editEmp = employeeService.editEmp(id,emp);
        return editEmp;
    }

    @DeleteMapping("/del/{id}")
    public Employee deleteEmployee(@PathVariable String id){
        employeeService.delEmp(id);
        return null;
    }

}

