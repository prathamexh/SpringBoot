import {
  Button,
  Heading,
  Table,
  Tbody,
  Td,
  Th,
  Thead,
  Tr,
  useDisclosure,
  FormLabel,
  FormControl,
} from "@chakra-ui/react";
import React, { useState, useEffect } from "react";
import {
  Input,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
} from "@chakra-ui/react";
import {} from "@chakra-ui/react";

import AddStud from "./AddStud";
import axios from "axios";

function Students() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [isEdit, setIsEdit] = useState(false)
  const initialRef = React.useRef(null);
  const finalRef = React.useRef(null);
  const url = "http://localhost:5093/api/StudentApi/Get";
  const [data, setData] = useState([]);
  // for edit
  const [formData2, setFormData2] = useState({
    id:null,
    name: "",
    section: "",
    email: "",
  });
  // for add
  const [formData, setFormData] = useState({
    id:null,
    name: "",
    section: "",
    email: "",
  });
  useEffect(() => {
    const fetchInfo = async () => {
      const res = await fetch(url);
      const d = await res.json();
      return setData(d);
    };
    fetchInfo();
  }, [data]);

  const removeUser = async (event) => {
    const id = event.target.name;
    try {
      const res = await axios.delete(
        `http://localhost:5093/api/StudentApi/del/id?Id=` + id
      );
      console.log("Item successfully deleted.");
    } catch (error) {
      alert(error);
    }
  };
  
  const process = async () => {
    if (formData2.id == null){
      console.log("inside if true")
      console.log(formData)
      var myObj = formData;
      myObj.id = 0;
    axios
      .post("http://localhost:5093/api/StudentApi", myObj)
      .then((res) => {
        setFormData({...formData,id:null, name: "", section: "", email: "" });
        setFormData2({...formData2,id:null, name: "", section: "", email: "" });
      })
      .catch((err) => console.log(err));
    } else{
      setFormData({...formData,id: formData2.id})
      
      console.log(formData,formData2)
      var myObj = formData;
      myObj.id = formData2.id;
      axios
      .put("http://localhost:5093/api/StudentApi", myObj)
      setFormData({...formData,id:null, name: "", section: "", email: "" });
      setFormData2({...formData2,id:null, name: "", section: "", email: "" });
    }
  };
  const handleInput = (event) => {
    
      console.log("not entering")
      setFormData({
        ...formData,
        [event.target.name]: event.target.value,
      });
    
   
  };

  const getEditData = (event) => {
    console.log(event.target.name) // make this as id of form2
    var locus = event.target.name;
    setFormData2({...formData2,id:locus, name: "", section: "", email: "" });
    
  }
  // const handleModalOpen = () =>{
  //   // window.alert("Fuck you mommy");
  //   return(
  //   <AddStud isOpen={isOpen} onOpen = {onOpen} onClose = {onClose} initialRef={initialRef} finalRef= {finalRef}/>
  // )}
  return (
    <>
      <Heading>HI THIS IS MY TABLE </Heading>
      <Button onClick={onOpen} colorScheme="whatsapp">Add Student</Button>
      {/* <Modal
        initialFocusRef={initialRef}
        finalFocusRef={finalRef}
        isOpen={isOpen}
        onClose={onClose}
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Add Student</ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
            <FormControl>
              <FormLabel>First name</FormLabel>
              <Input
                ref={initialRef}
                onChange={handleInput}
                value={formData2.name}
                placeholder="First name"
                name="name"
              />
            </FormControl>

            <FormControl mt={4}>
              <FormLabel>Section</FormLabel>
              <Input
                onChange={handleInput}
                value={formData2.section}
                placeholder="Section"
                name="section"
              />
            </FormControl>

            <FormControl mt={4}>
              <FormLabel>Email</FormLabel>
              <Input
                onChange={handleInput}
                value={formData2.email}
                placeholder="Email"
                name="email"
              />
            </FormControl>
          </ModalBody>

          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={process}>
              Save
            </Button>
            <Button onClick={onClose}>Cancel</Button>
          </ModalFooter>
        </ModalContent>
      </Modal> */}
      {/* add ka part is neeche */}
      <Modal
        initialFocusRef={initialRef}
        finalFocusRef={finalRef}
        isOpen={isOpen}
        onClose={onClose}
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Add Student</ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
            <FormControl>
              <FormLabel>First name</FormLabel>
              <Input
                ref={initialRef}
                onChange={handleInput}
                value={formData.name}
                placeholder="First name"
                name="name"
              />
            </FormControl>

            <FormControl mt={4}>
              <FormLabel>Section</FormLabel>
              <Input
                onChange={handleInput}
                value={formData.section}
                placeholder="Section"
                name="section"
              />
            </FormControl>

            <FormControl mt={4}>
              <FormLabel>Email</FormLabel>
              <Input
                onChange={handleInput}
                value={formData.email}
                placeholder="Email"
                name="email"
              />
            </FormControl>
          </ModalBody>

          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={process}>
              Save
            </Button>
            <Button onClick={onClose}>Cancel</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
      <Table variant="striped" colorScheme="teal">
        <Thead>
          <Tr>
            <Th>ID</Th>
            <Th>Name</Th>
            <Th>Section</Th>
            <Th>Email</Th>
            <Th>Edit</Th>
            <Th>delete</Th>
          </Tr>
        </Thead>
        <Tbody>
          {data.map((item, index) => (
            <Tr key={index} name = {item.id}>
              <Td>{item.id}</Td>
              <Td>{item.name}</Td>
              <Td>{item.section}</Td>
              <Td>{item.email}</Td>
              <Td>
                <Button name={item.id} onFocus={getEditData} onClick= {onOpen} colorScheme="yellow">Edit</Button>
              </Td>
              <Td>
                <Button name={item.id} onClick={removeUser} colorScheme="red">
                  Delete
                </Button>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </>
  );
}

export default Students;
