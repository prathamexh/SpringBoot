import "./App.css";
import Students from "./components/Students";
import { useState, useEffect } from "react";
import { ChakraProvider } from "@chakra-ui/react";

// function App() {
//   return (
// <Students></Students>
//   );
// }

// export default App;
function App() {
  return (
    <ChakraProvider>
      <div className="App">
        <Students />
      </div>
    </ChakraProvider>
  );
}

export default App;
