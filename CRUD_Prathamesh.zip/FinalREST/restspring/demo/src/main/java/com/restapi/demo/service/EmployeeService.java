package com.restapi.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restapi.demo.bean.Employee;
import com.restapi.demo.repository.EmployeeRepository;

@Service
public class EmployeeService  {

    
   // List<Employee> list;
        @Autowired
    private EmployeeRepository employeeRepository;
    
  
   // List<Employee> list = employeeRepository.findAll();
    //List<Employee> listOfEmp = employeeRepository.findAll();
    //List<Employee> list;
    public List<Employee> getAllEmployees() {
        List<Employee> listOfEmp = employeeRepository.findAll();
        return listOfEmp;
    }


    public Employee addNewEmployee(Employee emp) {
       // list.add(emp);
        return employeeRepository.save(emp);
        //return emp;
    }


    public Employee editEmp(String id, Employee emp) {
        long i =Integer.parseInt(id);
        
        Employee updateEmployee = employeeRepository.findById(i).orElse(null);

        updateEmployee.setName(emp.getName());
        updateEmployee.setCity(emp.getCity());
        updateEmployee.setSalary(emp.getSalary());

        employeeRepository.save(updateEmployee);

        return null;
    }

    public List<Employee> deadFunc(Employee emp){
        List<Employee> listOfEmp = employeeRepository.findAll();
        return listOfEmp;
    }

    public Employee getEmp(Long id){
       List<Employee> listOfEmp = employeeRepository.findAll();
        for(Employee emp:listOfEmp){
           
            if(emp.getEmpid()==id){
                return emp;
            }
        }
        return null;
    }

    public void delEmp(String id) {
        long i=Integer.parseInt(id);  
        employeeRepository.deleteById(i);
    } 
}
