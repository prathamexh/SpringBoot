from rest_framework import serializers
from EmployeeApp.models import Employees



class EmployeesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employees
        fields = ('Id', 'Name', 'Email', 'Address')

